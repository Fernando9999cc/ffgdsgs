﻿const Discord = require('discord.js');
const Config = require('./config.json');
const client = new Discord.Client();

var setTitle = require('console-title');
setTitle(`[BOT][CALL TEMPORARIA][🏆 Baile Da Sintonia 🏆]`)

var usuariosBloqueio = [];
var channelCount = 0;

function delayCreate(id) {
    usuariosBloqueio.push(id);
    setTimeout(() => {
        let indice = usuariosBloqueio.indexOf(id);
        usuariosBloqueio.splice(indice, 1);
    }, 10000);
}

function validCategory(id) {
    if(id == Config.cID){
        return true;
    }else{
        return false;
    }
}

function createChannel(channelInfo) {
    if(channelInfo.channel.id != Config.sID) return;
    let icone = channelInfo.guild.iconURL({dynamic: true})
    if(channelCount >= Config.quantCall){
        let msgEmbed = new Discord.MessageEmbed()
            .setColor('#03f4fc')
            .setTitle('🏆 Baile Da Sintonia 🏆')
            .setDescription('**Opa, já estamos no limite de sala, espere 1 ser removida e tente novamente :)**')
            .setThumbnail(icone)
            .setTimestamp()
            .setFooter('© Copyright Sweet Factory - Todos os direitos reservados');
        channelInfo.member.send(msgEmbed).catch(() => {});
        return channelInfo.member.voice.setChannel(null).catch(() => {});
    }
    if(usuariosBloqueio.includes(channelInfo.member.id)){
        let msgEmbed = new Discord.MessageEmbed()
            .setColor('#03f4fc')
            .setTitle('🏆 Baile Da Sintonia 🏆')
            .setDescription('**Opa, tudo bem? pelo que eu vi você está querendo criar uma sequencia de salas com um tempo de espera muito rapido, aguarde mais alguns segundos para poder criar :)**')
            .setThumbnail(icone)
            .setTimestamp()
            .setFooter('© Copyright Sweet Factory - Todos os direitos reservados');
        channelInfo.member.send(msgEmbed).catch(() => {});
        return channelInfo.member.voice.setChannel(null).catch(() => {});
    }

    let nameChannel = `${channelInfo.member.user.username}`;
    
    if (nameChannel.length <= 85){
        if(nameChannel.indexOf('BDS') != -1){
            nameChannel = `🏆 ${nameChannel}`;
        }else{
            nameChannel = `🏆 ${nameChannel} BDS`;
        }
    }

    channelInfo.channel.clone({ name: nameChannel, userLimit: 3, reason: 'Sala clonada por BOT de sala temporaria' }).then((ch) => {
        console.log(`LOGS: Sala ${nameChannel} foi criada com sucesso!`);
        delayCreate(channelInfo.member.id);
        channelCount = channelCount+1;
        channelInfo.member.voice.setChannel(ch).catch(() => {});
        ch.createOverwrite(channelInfo.member.user.id, {
            MANAGE_CHANNELS: true
        }).then(() => {
            console.log(`LOGS: Permissões para ${channelInfo.member.user.username} na sala ${nameChannel} adicionada!`);
        }).catch((err) => {
            console.log(`LOGS: Permissões para ${channelInfo.member.user.username} na sala ${nameChannel} não pode ser adicionada, erro abaixo!`);
            console.log(`+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+`);
            console.log(`ERRO: ${err}`);
            console.log(`+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+`);
        });
    }).catch((err) => {
        console.log(`LOGS: Sala ${nameChannel} não pode ser criada com sucesso, erro abaixo!`);
        console.log(`+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+`);
        console.log(`ERRO: ${err}`);
        console.log(`+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+`);
    });
}

function reChannel(channelInfo) {
    channelInfo = channelInfo.channel;

    if(channelInfo.id == Config.sID) return;
    if(channelInfo.members.size != 0) return;
    channelInfo.delete().then(() => {
        console.log(`LOGS: Sala ${channelInfo.name} foi removida com sucesso!`);
        channelCount = channelCount-1;
    }).catch((err) => {
        console.log(`LOGS: Sala ${channelInfo.name} não pode ser removida com sucesso, erro abaixo!`);
        console.log(`+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+`);
        console.log(`ERRO: ${err}`);
        console.log(`+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+`);
    });
}

client.on('ready', () => {
    console.clear();
    console.log(`+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+`);
    console.log(`Status: Iniciado`);
    console.log(`+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+`);
    console.log(`+ Identificação: ${client.user.id}`);
    console.log(`+ Nome: ${client.user.username}`);
    console.log(`+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+`);
});

client.on('voiceStateUpdate', (oldState, newState) => {
    let newUserChannel = newState.channel;
    let oldUserChannel = oldState.channel;
    
    if(newUserChannel != null && oldUserChannel != null){
        try {
            if(oldUserChannel != null){
                if(validCategory(oldUserChannel.parent.id)){
                    reChannel(oldState);
                }
            }
            if(newUserChannel != null){
                if(validCategory(newUserChannel.parent.id)){
                    createChannel(newState);
                }
            }
        } catch (error) {
            console.log(`Erro: Objeto voltando sem a proriedade necessaria.`);
        }
    }else{
        try {
            if(newUserChannel != null){
                if(validCategory(newUserChannel.parent.id)){
                    createChannel(newState);
                }
            }else if(oldUserChannel != null){
                if(validCategory(oldUserChannel.parent.id)){
                    reChannel(oldState);
                }
            }
        } catch (error) {
            console.log(`Erro: Objeto voltando sem a proriedade necessaria.`);
        }
    }

});

client.login(Config.token);